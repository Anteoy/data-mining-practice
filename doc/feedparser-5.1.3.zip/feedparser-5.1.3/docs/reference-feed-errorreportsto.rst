.. _reference.feed.errorreportsto:

:py:attr:`feed.errorreportsto`
==============================

An email address for reporting errors in the feed itself.

.. rubric:: Comes from

* /rdf:RDF/admin:errorReportsTo/@rdf:resource
